import React from 'react'
import {connect} from 'react-redux'
import { milliSec } from '../redux'

const Controller = props => {
    const setTimeFunc = () => {
        console.log('HIT')
        setInterval( props.milliSec, 10)
    }
    return(
        <div>
            <button onClick={setTimeFunc}>Start</button>
            {/* <button onClick={props}>Stop </button> */}
        </div>
    )
}

export default connect(null, {milliSec})(Controller)
