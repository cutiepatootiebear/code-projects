import React from 'react'
import { connect } from 'react-redux'

const Display = props => {
    console.log('this is props=> ', props)
    return(
        <div>
            <h1>Minutes: {props.minutes}'s</h1>
            <h1>milliseconds: {props.milliseconds}'s</h1>
            <h1>Seconds: {props.seconds}'s</h1>
            <h1>Hour: {props.hours}'s</h1>
        </div>
    )
}

export default connect(state=>state, {})(Display)